import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
} from 'react-native';

const HomeScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      
      {/* CABECERA CON TEXTO Y FOTO */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Proyecto Final</Text>
        <Text style={styles.headerSubtitle}>Desarrollo de Aplicaciones Moviles</Text>
        
        {/* FOTO - USANDO TU ARCHIVO logo.png */}
        <Image
          source={require('../assets/logo.png')}
          style={styles.profileImage}
        />
        
        <Text style={styles.namesTitle}>Integrantes:</Text>
        <Text style={styles.names}>Leonardo Joel Del Rio Romero</Text>
        <Text style={styles.names}>Roberto Chavez Moreno</Text>
        
        <View style={styles.separator} />
        
        {/* FRASES DEL PROYECTO */}
        <View style={styles.quotesContainer}>
          
        </View>
      </View>

      {/* INFORMACIÓN ADICIONAL */}
      <View style={styles.infoContainer}>
        <Text style={styles.infoTitle}>Explorador de Países</Text>
        <Text style={styles.infoText}>

        </Text>
        
        <View style={styles.features}>
          
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#1E88E5',
    padding: 25,
    borderBottomLeftRadius: 25,
    borderBottomRightRadius: 25,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 5,
    elevation: 8,
  },
  headerTitle: {
    fontSize: 32,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
    marginBottom: 5,
    textShadowColor: 'rgba(0, 0, 0, 0.3)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 3,
  },
  headerSubtitle: {
    fontSize: 18,
    color: 'white',
    textAlign: 'center',
    marginBottom: 25,
    fontWeight: '500',
  },
  profileImage: {
    width: 130,
    height: 130,
    borderRadius: 65,
    marginBottom: 20,
    borderWidth: 4,
    borderColor: 'white',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.3,
    shadowRadius: 5,
    elevation: 6,
  },
  namesTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 10,
    textAlign: 'center',
  },
  names: {
    fontSize: 18,
    color: 'white',
    marginBottom: 8,
    textAlign: 'center',
    fontWeight: '500',
  },
  separator: {
    height: 2,
    width: '80%',
    backgroundColor: 'rgba(255, 255, 255, 0.4)',
    marginVertical: 20,
  },
  quotesContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    borderRadius: 15,
    padding: 15,
    marginTop: 10,
    width: '90%',
  },
  quote: {
    fontSize: 16,
    color: '#FFD700',
    textAlign: 'center',
    marginBottom: 8,
    fontWeight: '600',
    fontStyle: 'italic',
  },
  infoContainer: {
    backgroundColor: 'white',
    margin: 20,
    padding: 25,
    borderRadius: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 5,
    marginTop: 30,
  },
  infoTitle: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#1E88E5',
    marginBottom: 15,
    textAlign: 'center',
  },
  infoText: {
    fontSize: 16,
    color: '#555',
    lineHeight: 24,
    marginBottom: 20,
    textAlign: 'center',
  },
  features: {
    backgroundColor: '#F0F8FF',
    borderRadius: 15,
    padding: 15,
    borderLeftWidth: 4,
    borderLeftColor: '#1E88E5',
  },
  feature: {
    fontSize: 14,
    color: '#333',
    marginBottom: 8,
    paddingLeft: 5,
  },
});

export default HomeScreen;
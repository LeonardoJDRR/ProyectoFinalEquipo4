import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
  ScrollView,
  ActivityIndicator,
} from 'react-native';

const CountryDetailsScreen = ({ route }) => {
  const { country } = route.params;
  const [countryDetails, setCountryDetails] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchCountryDetails();
  }, []);

  const fetchCountryDetails = async () => {
    try {
      if (country.cca3) {
        const response = await fetch(
          `https://restcountries.com/v3.1/alpha/${country.cca3}`
        );
        const data = await response.json();
        setCountryDetails(data[0]);
      }
      setLoading(false);
    } catch (error) {
      console.error('Error fetching country details:', error);
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color="#1E88E5" />
      </View>
    );
  }

  const data = countryDetails || country;

  return (
    <ScrollView style={styles.container}>
      <Image
        source={{ uri: data.flags.png }}
        style={styles.flag}
        resizeMode="contain"
      />
      
      <View style={styles.detailsContainer}>
        <Text style={styles.countryName}>{data.name.common}</Text>
        <Text style={styles.officialName}>{data.name.official}</Text>
        
        <View style={styles.infoSection}>
          <Text style={styles.sectionTitle}>Informacion General</Text>
          <Text style={styles.infoText}>
            Region: {data.region} {data.subregion ? `- ${data.subregion}` : ''}
          </Text>
          <Text style={styles.infoText}>
            Capital: {data.capital ? data.capital[0] : 'N/A'}
          </Text>
          <Text style={styles.infoText}>
            Poblacion: {data.population.toLocaleString()} habitantes
          </Text>
          <Text style={styles.infoText}>
            Area: {data.area.toLocaleString()} km2
          </Text>
        </View>

        <View style={styles.infoSection}>
          <Text style={styles.sectionTitle}>Idiomas</Text>
          {data.languages ? (
            Object.values(data.languages).map((lang, index) => (
              <Text key={index} style={styles.infoText}>
                {lang}
              </Text>
            ))
          ) : (
            <Text style={styles.infoText}>No disponible</Text>
          )}
        </View>

        <View style={styles.infoSection}>
          <Text style={styles.sectionTitle}>Moneda</Text>
          {data.currencies ? (
            Object.values(data.currencies).map((currency, index) => (
              <Text key={index} style={styles.infoText}>
                {currency.name} ({currency.symbol})
              </Text>
            ))
          ) : (
            <Text style={styles.infoText}>No disponible</Text>
          )}
        </View>

        <View style={styles.infoSection}>
          <Text style={styles.sectionTitle}>Zonas Horarias</Text>
          {data.timezones.map((timezone, index) => (
            <Text key={index} style={styles.infoText}>
              {timezone}
            </Text>
          ))}
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  flag: {
    width: '100%',
    height: 200,
    backgroundColor: '#fff',
  },
  detailsContainer: {
    padding: 20,
  },
  countryName: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 5,
  },
  officialName: {
    fontSize: 16,
    color: '#666',
    marginBottom: 20,
    fontStyle: 'italic',
  },
  infoSection: {
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 15,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1E88E5',
    marginBottom: 10,
  },
  infoText: {
    fontSize: 16,
    color: '#333',
    marginBottom: 8,
  },
});

export default CountryDetailsScreen;
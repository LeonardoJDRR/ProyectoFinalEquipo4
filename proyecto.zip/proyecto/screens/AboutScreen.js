import React from 'react';
import { StyleSheet, Text, View, ScrollView } from 'react-native';

const AboutScreen = () => {
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Acerca de la API</Text>
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Aplicacion de Paises</Text>
        <Text style={styles.text}>
          Esta aplicacion muestra informacion detallada sobre todos los paises del mundo, utilizando la API publica de REST Countries.
        </Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>API Utilizada</Text>
        <Text style={styles.text}>
          REST Countries API v3.1
          Datos actualizados sobre paises
          Informacion demografica, geografica y cultural
          Banderas y detalles oficiales
        </Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Caracteristicas</Text>
        <Text style={styles.text}>
          Lista completa de paises
          Busqueda por nombre
          Detalles completos de cada pais
          Navegacion entre pantallas
          Interfaz amigable y responsiva
        </Text>
      </View>

     
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#333',
    textAlign: 'center',
  },
  section: {
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#1E88E5',
  },
  text: {
    fontSize: 16,
    lineHeight: 24,
    color: '#333',
  },
});

export default AboutScreen;
import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import BottomTabNavigator from './BottomTabNavigator';
import CountryDetailsScreen from '../screens/CountryDetailsScreen';

const Stack = createStackNavigator();

function StackNavigator() {
  return (
    <Stack.Navigator>
      <Stack.Screen 
        name="MainTabs" 
        component={BottomTabNavigator} 
        options={{ headerShown: false }}
      />
      <Stack.Screen 
        name="CountryDetails" 
        component={CountryDetailsScreen}
        options={{ title: 'Detalles del Pais' }}
      />
    </Stack.Navigator>
  );
}

export default StackNavigator;